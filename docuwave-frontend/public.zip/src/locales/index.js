import en from './en.json';
import ar from './ar.json';
import fr from './fr.json';

const translations = {
  en,
  ar,
  fr
};

export default translations;