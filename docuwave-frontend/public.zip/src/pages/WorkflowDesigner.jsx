import React, { useState, useRef } from 'react';
import { Save, Play, Plus, Settings, Trash2, Link, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';
import { useTranslations } from '../hooks/useTranslations';

function WorkflowDesigner({ showToast }) {
  const { t } = useTranslations();
  const [workflowName, setWorkflowName] = useState('Invoice Processing Workflow');
  const [isEditingName, setIsEditingName] = useState(false);
  const [selectedNode, setSelectedNode] = useState(null);
  const [nodes, setNodes] = useState([
    { id: 1, type: 'start', label: 'Start', x: 100, y: 200, color: 'bg-green-500' },
    { id: 2, type: 'ai', label: 'AI Classification', x: 350, y: 200, color: 'bg-blue-500' },
    { id: 3, type: 'form', label: 'Data Entry Form', x: 600, y: 200, color: 'bg-purple-500', formId: null },
    { id: 4, type: 'approval', label: 'Manager Approval', x: 850, y: 200, color: 'bg-yellow-500' },
    { id: 5, type: 'end', label: 'End', x: 1100, y: 200, color: 'bg-red-500' }
  ]);
  const [connections, setConnections] = useState([
    { from: 1, to: 2 },
    { from: 2, to: 3 },
    { from: 3, to: 4 },
    { from: 4, to: 5 }
  ]);
  const [draggingNode, setDraggingNode] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [showProperties, setShowProperties] = useState(true);
  const canvasRef = useRef(null);

  const nodeTypes = [
    { id: 'ai', label: 'AI Task', icon: '🤖', color: 'bg-blue-500', description: 'AI Classification/Extraction' },
    { id: 'form', label: 'Form Step', icon: '📝', color: 'bg-purple-500', description: 'User form input' },
    { id: 'approval', label: 'Approval', icon: '✓', color: 'bg-yellow-500', description: 'Human approval step' },
    { id: 'conditional', label: 'Conditional', icon: '⚡', color: 'bg-orange-500', description: 'If/Else logic' },
    { id: 'email', label: 'Send Email', icon: '✉️', color: 'bg-pink-500', description: 'Email notification' },
    { id: 'webhook', label: 'Webhook', icon: '🔗', color: 'bg-indigo-500', description: 'Call external API' }
  ];

  const availableForms = [
    { id: '1', name: 'Invoice Extraction Form' },
    { id: '2', name: 'Contract Review Form' },
    { id: '3', name: 'Receipt Data Form' },
    { id: '4', name: 'Approval Form' }
  ];

  const handleNodeDragStart = (e, node) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
    setDraggingNode(node);
  };

  const handleCanvasDragOver = (e) => {
    e.preventDefault();
  };

  const handleCanvasDrop = (e) => {
    e.preventDefault();
    if (!draggingNode) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - dragOffset.x) / zoom;
    const y = (e.clientY - rect.top - dragOffset.y) / zoom;

    if (nodes.find(n => n.id === draggingNode.id)) {
      // Moving existing node
      setNodes(nodes.map(n => 
        n.id === draggingNode.id ? { ...n, x, y } : n
      ));
    } else {
      // Adding new node from palette
      const newNode = {
        id: Date.now(),
        type: draggingNode.id,
        label: draggingNode.label,
        x,
        y,
        color: draggingNode.color,
        formId: draggingNode.id === 'form' ? null : undefined
      };
      setNodes([...nodes, newNode]);
      showToast(`${draggingNode.label} added to workflow`, 'success');
    }

    setDraggingNode(null);
  };

  const handlePaletteDragStart = (e, nodeType) => {
    setDraggingNode(nodeType);
  };

  const deleteNode = (nodeId) => {
    setNodes(nodes.filter(n => n.id !== nodeId));
    setConnections(connections.filter(c => c.from !== nodeId && c.to !== nodeId));
    setSelectedNode(null);
    showToast('Node deleted', 'success');
  };

  const connectNodes = (fromId, toId) => {
    const exists = connections.find(c => c.from === fromId && c.to === toId);
    if (!exists) {
      setConnections([...connections, { from: fromId, to: toId }]);
      showToast('Nodes connected', 'success');
    }
  };

  const autoConnect = () => {
    if (selectedNode && nodes.length > 1) {
      const currentIndex = nodes.findIndex(n => n.id === selectedNode.id);
      if (currentIndex < nodes.length - 1) {
        const nextNode = nodes[currentIndex + 1];
        connectNodes(selectedNode.id, nextNode.id);
      }
    }
  };

  const handleSaveWorkflow = () => {
    const workflow = {
      name: workflowName,
      nodes,
      connections
    };
    console.log('Saving workflow:', workflow);
    showToast('Workflow saved successfully!', 'success');
  };

  const handleDeployWorkflow = () => {
    showToast('Workflow deployed!', 'success');
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.1, 2));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.1, 0.5));
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="flex justify-between items-center p-4 bg-white border-b">
        <div className="flex items-center gap-3">
          {isEditingName ? (
            <input
              type="text"
              value={workflowName}
              onChange={(e) => setWorkflowName(e.target.value)}
              onBlur={() => setIsEditingName(false)}
              onKeyPress={(e) => e.key === 'Enter' && setIsEditingName(false)}
              className="text-xl font-bold border-b-2 border-blue-500 outline-none"
              autoFocus
            />
          ) : (
            <h2 
              className="text-xl font-bold cursor-pointer hover:text-blue-600"
              onClick={() => setIsEditingName(true)}
              title="Click to edit"
            >
              {workflowName}
            </h2>
          )}
          <span className="text-sm text-gray-500">
            {nodes.length} nodes, {connections.length} connections
          </span>
        </div>
        <div className="flex gap-2">
          <div className="flex gap-1 border rounded">
            <button 
              onClick={handleZoomOut}
              className="px-3 py-2 hover:bg-gray-100"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="px-3 py-2 border-x text-sm">{Math.round(zoom * 100)}%</span>
            <button 
              onClick={handleZoomIn}
              className="px-3 py-2 hover:bg-gray-100"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>
          <button 
            onClick={() => setShowProperties(!showProperties)}
            className="px-4 py-2 border rounded hover:bg-gray-50"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button 
            onClick={handleSaveWorkflow}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            Save
          </button>
          <button 
            onClick={handleDeployWorkflow}
            className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center gap-2"
          >
            <Play className="w-4 h-4" />
            Deploy
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Node Palette */}
        <div className="w-64 bg-white border-r overflow-y-auto">
          <div className="p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Components
            </h3>
            <p className="text-xs text-gray-500 mb-3">Drag to canvas</p>
            <div className="space-y-2">
              {nodeTypes.map(nodeType => (
                <div
                  key={nodeType.id}
                  draggable
                  onDragStart={(e) => handlePaletteDragStart(e, nodeType)}
                  className={`${nodeType.color} text-white p-3 rounded cursor-move hover:opacity-90 transition-opacity`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xl">{nodeType.icon}</span>
                    <span className="text-sm font-medium">{nodeType.label}</span>
                  </div>
                  <p className="text-xs opacity-80">{nodeType.description}</p>
                </div>
              ))}
            </div>

            <div className="mt-6 p-3 bg-blue-50 rounded text-xs text-blue-800">
              <strong>💡 Tips:</strong>
              <ul className="mt-2 space-y-1 list-disc list-inside">
                <li>Drag nodes to canvas</li>
                <li>Click to select & edit</li>
                <li>Drag selected to connect</li>
                <li>Delete with trash icon</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Canvas */}
        <div 
          ref={canvasRef}
          onDragOver={handleCanvasDragOver}
          onDrop={handleCanvasDrop}
          className="flex-1 overflow-auto bg-gray-50 relative"
          style={{ 
            backgroundImage: 'radial-gradient(circle, #d1d5db 1px, transparent 1px)', 
            backgroundSize: `${20 * zoom}px ${20 * zoom}px` 
          }}
        >
          <div 
            style={{ 
              transform: `scale(${zoom})`,
              transformOrigin: 'top left',
              width: '2000px',
              height: '1200px',
              position: 'relative'
            }}
          >
            {/* Connection Lines */}
            <svg 
              className="absolute inset-0 pointer-events-none" 
              style={{ width: '2000px', height: '1200px', zIndex: 1 }}
            >
              {connections.map((conn, idx) => {
                const fromNode = nodes.find(n => n.id === conn.from);
                const toNode = nodes.find(n => n.id === conn.to);
                if (!fromNode || toNode) {
                  const x1 = fromNode.x + 80;
                  const y1 = fromNode.y + 30;
                  const x2 = toNode.x;
                  const y2 = toNode.y + 30;
                  
                  // Curved line
                  const midX = (x1 + x2) / 2;
                  const path = `M ${x1} ${y1} Q ${midX} ${y1}, ${midX} ${(y1 + y2) / 2} T ${x2} ${y2}`;
                  
                  return (
                    <g key={`line-${idx}`}>
                      <path
                        d={path}
                        stroke="#3b82f6"
                        strokeWidth="2"
                        fill="none"
                        markerEnd="url(#arrowhead)"
                      />
                    </g>
                  );
                }
                return null;
              })}
              <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                  <polygon points="0 0, 10 3, 0 6" fill="#3b82f6" />
                </marker>
              </defs>
            </svg>

            {/* Nodes */}
            {nodes.map(node => (
              <div
                key={node.id}
                draggable
                onDragStart={(e) => handleNodeDragStart(e, node)}
                className={`absolute ${node.color} text-white p-4 rounded-lg shadow-lg cursor-move hover:shadow-xl transition-all ${
                  selectedNode?.id === node.id ? 'ring-4 ring-blue-400 scale-105' : ''
                }`}
                style={{ left: node.x, top: node.y, width: '160px', zIndex: 10 }}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedNode(node);
                }}
              >
                <div className="text-center">
                  <div className="text-2xl mb-1">
                    {nodeTypes.find(t => t.id === node.type)?.icon || '📦'}
                  </div>
                  <div className="text-sm font-semibold">{node.label}</div>
                  <div className="text-xs opacity-75 mt-1 capitalize">{node.type}</div>
                </div>
                {node.type !== 'start' && node.type !== 'end' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteNode(node.id);
                    }}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 shadow-lg"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}

            {nodes.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                <div className="text-center">
                  <Plus className="w-16 h-16 mx-auto mb-3 opacity-30" />
                  <p className="text-lg">Drag components from the left panel</p>
                  <p className="text-sm mt-1">to start building your workflow</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Properties Panel */}
        {showProperties && (
          <div className="w-80 bg-white border-l overflow-y-auto">
            <div className="p-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Properties
                </h3>
                <button 
                  onClick={() => setShowProperties(false)}
                  className="p-1 hover:bg-gray-100 rounded"
                >
                  ✕
                </button>
              </div>
              
              {selectedNode ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 block mb-1">Node ID</label>
                    <input
                      type="text"
                      value={selectedNode.id}
                      disabled
                      className="w-full px-3 py-2 border rounded bg-gray-50 text-sm"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 block mb-1">Label</label>
                    <input
                      type="text"
                      value={selectedNode.label}
                      onChange={(e) => {
                        setNodes(nodes.map(n => 
                          n.id === selectedNode.id ? { ...n, label: e.target.value } : n
                        ));
                        setSelectedNode({ ...selectedNode, label: e.target.value });
                      }}
                      className="w-full px-3 py-2 border rounded text-sm"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 block mb-1">Type</label>
                    <input
                      type="text"
                      value={selectedNode.type}
                      disabled
                      className="w-full px-3 py-2 border rounded bg-gray-50 text-sm capitalize"
                    />
                  </div>

                  {/* Form-specific properties */}
                  {selectedNode.type === 'form' && (
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-1">Select Form</label>
                      <select 
                        value={selectedNode.formId || ''}
                        onChange={(e) => {
                          setNodes(nodes.map(n => 
                            n.id === selectedNode.id ? { ...n, formId: e.target.value } : n
                          ));
                          setSelectedNode({ ...selectedNode, formId: e.target.value });
                        }}
                        className="w-full px-3 py-2 border rounded text-sm"
                      >
                        <option value="">Choose form...</option>
                        {availableForms.map(form => (
                          <option key={form.id} value={form.id}>{form.name}</option>
                        ))}
                      </select>
                      {selectedNode.formId && (
                        <p className="text-xs text-green-600 mt-1">✓ Form selected</p>
                      )}
                    </div>
                  )}

                  {/* AI-specific properties */}
                  {selectedNode.type === 'ai' && (
                    <>
                      <div>
                        <label className="text-sm font-medium text-gray-700 block mb-1">AI Model</label>
                        <select className="w-full px-3 py-2 border rounded text-sm">
                          <option>GPT-4</option>
                          <option>Claude 3</option>
                          <option>Local LLM</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 block mb-1">Task</label>
                        <select className="w-full px-3 py-2 border rounded text-sm">
                          <option>Classification</option>
                          <option>Extraction</option>
                          <option>Summarization</option>
                        </select>
                      </div>
                    </>
                  )}

                  {/* Approval-specific properties */}
                  {selectedNode.type === 'approval' && (
                    <div>
                      <label className="text-sm font-medium text-gray-700 block mb-1">Approver</label>
                      <select className="w-full px-3 py-2 border rounded text-sm">
                        <option>Manager</option>
                        <option>Finance Team</option>
                        <option>Admin</option>
                        <option>Any User</option>
                      </select>
                    </div>
                  )}

                  {/* Email-specific properties */}
                  {selectedNode.type === 'email' && (
                    <>
                      <div>
                        <label className="text-sm font-medium text-gray-700 block mb-1">To</label>
                        <input
                          type="email"
                          placeholder="recipient@example.com"
                          className="w-full px-3 py-2 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 block mb-1">Subject</label>
                        <input
                          type="text"
                          placeholder="Email subject"
                          className="w-full px-3 py-2 border rounded text-sm"
                        />
                      </div>
                    </>
                  )}

                  <div className="pt-4 border-t">
                    <h4 className="text-sm font-semibold mb-2">Position</h4>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-xs text-gray-600">X</label>
                        <input
                          type="number"
                          value={Math.round(selectedNode.x)}
                          onChange={(e) => {
                            const newX = parseInt(e.target.value) || 0;
                            setNodes(nodes.map(n => 
                              n.id === selectedNode.id ? { ...n, x: newX } : n
                            ));
                            setSelectedNode({ ...selectedNode, x: newX });
                          }}
                          className="w-full px-2 py-1 border rounded text-sm"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-600">Y</label>
                        <input
                          type="number"
                          value={Math.round(selectedNode.y)}
                          onChange={(e) => {
                            const newY = parseInt(e.target.value) || 0;
                            setNodes(nodes.map(n => 
                              n.id === selectedNode.id ? { ...n, y: newY } : n
                            ));
                            setSelectedNode({ ...selectedNode, y: newY });
                          }}
                          className="w-full px-2 py-1 border rounded text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  {selectedNode.type !== 'start' && selectedNode.type !== 'end' && (
                    <button
                      onClick={() => deleteNode(selectedNode.id)}
                      className="w-full mt-4 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 flex items-center justify-center gap-2"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete Node
                    </button>
                  )}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <Settings className="w-12 h-12 mx-auto mb-3 opacity-30" />
                  <p className="text-sm">Select a node to view and edit its properties</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default WorkflowDesigner;